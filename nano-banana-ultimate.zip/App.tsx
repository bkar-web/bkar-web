


import React, { useState, useEffect } from 'react';
import { AppState, DropdownOption } from './types';
import * as Constants from './constants';
import Dropdown from './components/Dropdown';
import ImageUploader from './components/ImageUploader';
import { generatePortrait } from './services/gemini';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    // Mode
    mode: 'generate',

    // Generation State
    referenceImages: { front: null, left: null, right: null },
    subject: 'Male',
    emotion: 'Default (AI)',
    framing: 'Default (AI)',
    aspectRatio: '1:1', // Default Aspect Ratio
    skinRetouch: 'Off (Realistic Texture)',
    
    hairstyle: 'Default (AI)',
    facialHair: 'None / Clean Shaven',
    eyeColor: 'Default (AI)',
    bodyType: 'Default (AI)',
    attireCategory: 'Western',
    attire: 'Default (AI)',
    accessories: 'None', // New
    
    sceneMode: 'Location',
    vehicleType: 'Sedan',
    vehicleModel: 'Mercedes-Benz S-Class',
    vehicleContext: 'Outside', // Default
    vehiclePosition: 'Standing in Front', // Default
    vehicleEnvironment: 'Open Highway',
    locationCategory: 'Parks',
    locationDetail: '',
    filter: 'None',
    customPrompt: '',

    // Edit State
    editImage: null,
    editPrompt: '',
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [generatedPrompt, setGeneratedPrompt] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const updateState = (key: keyof AppState, value: any) => {
    setState((prev) => ({ ...prev, [key]: value }));
  };

  // Dynamic Options based on Subject
  const getHairstyles = (): DropdownOption[] => {
    if (['Female', 'Girl'].includes(state.subject)) {
      return Constants.FEMALE_HAIRSTYLES;
    }
    return Constants.MALE_HAIRSTYLES;
  };

  const isMaleSubject = (): boolean => {
    return ['Male', 'Boy'].includes(state.subject);
  };

  const getAttire = (): DropdownOption[] => {
    const isFemale = ['Female', 'Girl'].includes(state.subject);
    if (state.attireCategory === 'Western') {
      return isFemale ? Constants.FEMALE_WESTERN_ATTIRE : Constants.MALE_WESTERN_ATTIRE;
    } else {
      return isFemale ? Constants.FEMALE_EASTERN_ATTIRE : Constants.MALE_EASTERN_ATTIRE;
    }
  };

  const getVehicleModels = (): DropdownOption[] => {
    switch (state.vehicleType) {
      case 'Sedan': return Constants.SEDAN_MODELS;
      case 'SUV': return Constants.SUV_MODELS;
      case 'Supercar': return Constants.SUPERCAR_MODELS;
      case 'Sports Car': return Constants.SPORTS_CAR_MODELS;
      case 'Superbike': return Constants.SUPERBIKE_MODELS;
      case 'Vintage': return Constants.VINTAGE_MODELS;
      case 'Truck': return Constants.TRUCK_MODELS;
      case 'Aircraft': return Constants.AIRCRAFT_MODELS;
      case 'Yacht': return Constants.YACHT_MODELS;
      default: return Constants.SEDAN_MODELS;
    }
  };

  const getVehiclePositions = (): DropdownOption[] => {
    if (state.vehicleContext === 'Inside') {
      return Constants.VEHICLE_POSITIONS_INSIDE;
    }
    return Constants.VEHICLE_POSITIONS_OUTSIDE;
  };

  // Reset dependent fields when subject changes
  useEffect(() => {
    updateState('hairstyle', 'Default (AI)');
    updateState('attire', 'Default (AI)');
    if (!isMaleSubject()) {
        updateState('facialHair', 'None / Clean Shaven');
    }
  }, [state.subject, state.attireCategory]);

  // Reset vehicle model when vehicle type changes
  useEffect(() => {
    const models = getVehicleModels();
    if (models.length > 0) {
      updateState('vehicleModel', models[0].id);
    }
  }, [state.vehicleType]);

  // Reset Position when Context Changes
  useEffect(() => {
     if (state.vehicleContext === 'Inside') {
       updateState('vehiclePosition', 'Driver Seat');
     } else {
       updateState('vehiclePosition', 'Standing in Front');
     }
  }, [state.vehicleContext]);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError(null);
    setGeneratedImage(null);
    setGeneratedPrompt(null);

    let prompt = "";
    let refImages: string[] = [];

    if (state.mode === 'generate') {
      refImages = [
        state.referenceImages.front,
        state.referenceImages.left,
        state.referenceImages.right
      ].filter(Boolean) as string[];

      const hasRefs = refImages.length > 0;

      // Construct Generation Prompt
      if (hasRefs) {
        prompt = `Generate a hyper-realistic portrait of the person provided in the reference images. You MUST preserve the facial identity, features, and bone structure of the reference person. The generated face should look exactly like the person in the images. `;
      } else {
        prompt = `Create a hyper-realistic high-quality portrait. `;
      }
      
      // Subject & Core
      prompt += `Subject: ${state.subject}. `;
      prompt += `Body Type: ${state.bodyType}. `;
      prompt += `Emotion: ${state.emotion}. `;
      prompt += `Framing: ${state.framing}. `;
      prompt += `Skin Texture: ${state.skinRetouch}. `;
      prompt += `Eye Color: ${state.eyeColor}. `;
      
      // Appearance
      prompt += `Hairstyle: ${state.hairstyle}. `;
      if (isMaleSubject() && state.facialHair !== 'None / Clean Shaven') {
        prompt += `Facial Hair: ${state.facialHair}. `;
      }
      if (state.accessories !== 'None') {
        prompt += `Accessories: ${state.accessories}. `;
      }
      prompt += `Attire: ${state.attire} (${state.attireCategory} style). `;
      
      // Scene
      if (state.sceneMode === 'Vehicle') {
        prompt += `Setting: ${state.vehicleModel} (${state.vehicleType}). `;
        prompt += `Context: ${state.vehicleContext === 'Inside' ? 'Inside the vehicle' : 'Outside/Near the vehicle'}. `;
        prompt += `Pose/Position: ${state.vehiclePosition}. `;
        prompt += `Environment: ${state.vehicleEnvironment}. `;
      } else {
        prompt += `Setting: ${state.locationCategory} ${state.locationDetail ? `- ${state.locationDetail}` : ''}. `;
      }
      
      // Filter
      if (state.filter !== 'None') {
        prompt += `Color Grading/Filter Style: ${state.filter}. `;
      }

      // Custom
      if (state.customPrompt) {
        prompt += ` Additional Instructions: ${state.customPrompt}`;
      }

    } else {
      // Edit Mode
      if (!state.editImage) {
        setError("Please upload an image to edit.");
        setIsGenerating(false);
        return;
      }
      if (!state.editPrompt) {
         setError("Please describe what you want to change.");
         setIsGenerating(false);
         return;
      }
      prompt = `Edit this image. Instructions: ${state.editPrompt}`;
      refImages = [state.editImage];
    }

    setGeneratedPrompt(prompt);

    try {
      const result = await generatePortrait({
        prompt,
        referenceImages: refImages,
        aspectRatio: state.aspectRatio,
      });
      setGeneratedImage(result);
    } catch (err: any) {
      setError(err.message || 'Failed to generate image');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-200 pb-20">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#0f172a]/95 backdrop-blur-md border-b border-slate-800 px-6 py-4 flex items-center gap-4 shadow-md">
        <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center shrink-0 shadow-lg shadow-orange-500/20">
          <i className="fa-solid fa-pen-nib text-white text-lg"></i>
        </div>
        <div>
           <h1 className="text-xl font-black tracking-tight text-white leading-tight">
             NANO BANANA <span className="text-orange-500">ULTIMATE V3</span>
           </h1>
           <p className="text-[10px] text-slate-500 font-medium uppercase tracking-widest">AI Portrait Architect</p>
        </div>
      </header>

      <main className="px-4 py-8 w-full max-w-6xl mx-auto space-y-8">

        {/* Mode Switcher */}
        <div className="flex p-1 bg-slate-900 rounded-xl border border-slate-800 max-w-md mx-auto relative z-40">
           <button 
             onClick={() => updateState('mode', 'generate')}
             className={`flex-1 py-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${state.mode === 'generate' ? 'bg-orange-500 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
           >
             <i className="fa-solid fa-wand-magic-sparkles mr-2"></i>Generate
           </button>
           <button 
             onClick={() => updateState('mode', 'edit')}
             className={`flex-1 py-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${state.mode === 'edit' ? 'bg-orange-500 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
           >
             <i className="fa-solid fa-pen-to-square mr-2"></i>Edit Image
           </button>
        </div>
        
        {state.mode === 'generate' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Column (Inputs) */}
            <div className="lg:col-span-8 space-y-8">
              
              {/* 1. Reference Face - Highest z-index after header */}
              <section className="animate-fade-in bg-slate-900/50 p-6 rounded-2xl border border-slate-800/50 relative" style={{ zIndex: 40 }}>
                <h2 className="text-xs font-bold text-orange-500 uppercase tracking-widest mb-6 flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-orange-500/20 text-orange-500 flex items-center justify-center text-[10px]">1</span>
                  Reference Face
                </h2>
                <div className="grid grid-cols-3 gap-4 md:gap-6">
                  <ImageUploader 
                    label="Front View" 
                    image={state.referenceImages.front} 
                    onUpload={(img) => updateState('referenceImages', { ...state.referenceImages, front: img })} 
                  />
                  <ImageUploader 
                    label="Left View" 
                    image={state.referenceImages.left} 
                    onUpload={(img) => updateState('referenceImages', { ...state.referenceImages, left: img })} 
                  />
                  <ImageUploader 
                    label="Right View" 
                    image={state.referenceImages.right} 
                    onUpload={(img) => updateState('referenceImages', { ...state.referenceImages, right: img })} 
                  />
                </div>
              </section>

              {/* 2. Core Identity - Lower z-index than above */}
              <section className="animate-fade-in delay-100 bg-slate-900/50 p-6 rounded-2xl border border-slate-800/50 relative" style={{ zIndex: 30 }}>
                <h2 className="text-xs font-bold text-orange-500 uppercase tracking-widest mb-6 flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-orange-500/20 text-orange-500 flex items-center justify-center text-[10px]">2</span>
                  Core Identity & Framing
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <Dropdown 
                    label="Subject" 
                    options={Constants.SUBJECTS} 
                    value={state.subject} 
                    onChange={(v) => updateState('subject', v)} 
                  />
                  <Dropdown 
                    label="Body Type" 
                    options={Constants.BODY_TYPES} 
                    value={state.bodyType} 
                    onChange={(v) => updateState('bodyType', v)} 
                  />
                  <Dropdown 
                    label="Emotion" 
                    options={Constants.EMOTIONS} 
                    value={state.emotion} 
                    onChange={(v) => updateState('emotion', v)} 
                  />
                  <Dropdown 
                    label="Framing" 
                    options={Constants.FRAMING} 
                    value={state.framing} 
                    onChange={(v) => updateState('framing', v)} 
                  />
                  <Dropdown 
                    label="Aspect Ratio" 
                    options={Constants.ASPECT_RATIOS} 
                    value={state.aspectRatio} 
                    onChange={(v) => updateState('aspectRatio', v)} 
                  />
                  <Dropdown 
                    label="Skin Retouch" 
                    options={Constants.SKIN_RETOUCH} 
                    value={state.skinRetouch} 
                    onChange={(v) => updateState('skinRetouch', v)} 
                  />
                  <Dropdown 
                    label="Eye Color" 
                    options={Constants.EYE_COLORS} 
                    value={state.eyeColor} 
                    onChange={(v) => updateState('eyeColor', v)} 
                  />
                </div>
              </section>

              {/* 3. Appearance - Lower z-index */}
              <section className="animate-fade-in delay-200 bg-slate-900/50 p-6 rounded-2xl border border-slate-800/50 relative" style={{ zIndex: 20 }}>
                <h2 className="text-xs font-bold text-orange-500 uppercase tracking-widest mb-6 flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-orange-500/20 text-orange-500 flex items-center justify-center text-[10px]">3</span>
                  Appearance
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Dropdown 
                    label="Hairstyle" 
                    options={getHairstyles()} 
                    value={state.hairstyle} 
                    onChange={(v) => updateState('hairstyle', v)} 
                  />
                  
                  {isMaleSubject() && (
                    <Dropdown 
                      label="Facial Hair" 
                      options={Constants.FACIAL_HAIR} 
                      value={state.facialHair} 
                      onChange={(v) => updateState('facialHair', v)} 
                    />
                  )}
                  
                  <Dropdown 
                    label="Accessories" 
                    options={Constants.ACCESSORIES} 
                    value={state.accessories} 
                    onChange={(v) => updateState('accessories', v)} 
                  />

                  <div className={`space-y-2 ${isMaleSubject() ? 'md:col-span-1' : 'md:col-span-1'}`}>
                    <div className="flex gap-2 mb-1">
                      <button 
                        onClick={() => updateState('attireCategory', 'Western')}
                        className={`flex-1 py-1.5 text-[10px] uppercase font-bold rounded-lg border transition-all ${state.attireCategory === 'Western' ? 'bg-orange-500 border-orange-500 text-white' : 'bg-transparent border-slate-700 text-slate-500 hover:border-slate-500'}`}
                      >
                        Western
                      </button>
                      <button 
                        onClick={() => updateState('attireCategory', 'Eastern')}
                        className={`flex-1 py-1.5 text-[10px] uppercase font-bold rounded-lg border transition-all ${state.attireCategory === 'Eastern' ? 'bg-orange-500 border-orange-500 text-white' : 'bg-transparent border-slate-700 text-slate-500 hover:border-slate-500'}`}
                      >
                        Eastern
                      </button>
                    </div>
                    <Dropdown 
                      label={`Attire (${state.attireCategory})`}
                      options={getAttire()} 
                      value={state.attire} 
                      onChange={(v) => updateState('attire', v)} 
                    />
                  </div>
                </div>
              </section>

              {/* 4. Interactive Scene - Lowest z-index */}
              <section className="bg-[#151f32] rounded-2xl p-6 border border-slate-800 animate-fade-in delay-300 shadow-xl relative" style={{ zIndex: 10 }}>
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
                  <h2 className="text-xs font-bold text-orange-500 uppercase tracking-widest flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-orange-500/20 text-orange-500 flex items-center justify-center text-[10px]">4</span>
                    Interactive Scene
                  </h2>
                  <div className="flex bg-slate-900 rounded-lg p-1 self-start md:self-auto">
                    <button 
                      onClick={() => updateState('sceneMode', 'Location')}
                      className={`px-6 py-2 rounded-md text-[10px] font-bold uppercase transition-all ${state.sceneMode === 'Location' ? 'bg-orange-500 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                    >
                      Location
                    </button>
                    <button 
                      onClick={() => updateState('sceneMode', 'Vehicle')}
                      className={`px-6 py-2 rounded-md text-[10px] font-bold uppercase transition-all ${state.sceneMode === 'Vehicle' ? 'bg-orange-500 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                    >
                      Vehicle
                    </button>
                  </div>
                </div>

                {state.sceneMode === 'Vehicle' ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="lg:col-span-3">
                      <Dropdown 
                        label="Vehicle Type" 
                        options={Constants.VEHICLE_TYPES} 
                        value={state.vehicleType} 
                        onChange={(v) => updateState('vehicleType', v)} 
                      />
                    </div>
                    <Dropdown 
                      label="Select Model" 
                      options={getVehicleModels()} 
                      value={state.vehicleModel} 
                      onChange={(v) => updateState('vehicleModel', v)} 
                    />
                    <Dropdown 
                        label="Context" 
                        options={Constants.VEHICLE_CONTEXTS} 
                        value={state.vehicleContext} 
                        onChange={(v) => updateState('vehicleContext', v)} 
                    />
                    <Dropdown 
                        label="Position" 
                        options={getVehiclePositions()} 
                        value={state.vehiclePosition} 
                        onChange={(v) => updateState('vehiclePosition', v)} 
                    />
                    <Dropdown 
                      label="Environment" 
                      options={Constants.ENVIRONMENTS} 
                      value={state.vehicleEnvironment} 
                      onChange={(v) => updateState('vehicleEnvironment', v)} 
                    />
                     <Dropdown 
                      label="Color Grading / Filter" 
                      options={Constants.FILTERS} 
                      value={state.filter} 
                      onChange={(v) => updateState('filter', v)} 
                    />
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Dropdown 
                      label="Location Category" 
                      options={Constants.LOCATIONS} 
                      value={state.locationCategory} 
                      onChange={(v) => updateState('locationCategory', v)} 
                    />
                     <Dropdown 
                      label="Color Grading / Filter" 
                      options={Constants.FILTERS} 
                      value={state.filter} 
                      onChange={(v) => updateState('filter', v)} 
                    />
                    <div className="md:col-span-2">
                      <label className="text-xs font-bold text-orange-500 uppercase tracking-wider mb-1.5 ml-1 block">Specific Detail (Optional)</label>
                      <input 
                        type="text" 
                        placeholder="E.g. Central Park bench, Tokyo street..." 
                        value={state.locationDetail}
                        onChange={(e) => updateState('locationDetail', e.target.value)}
                        className="w-full bg-[#1e293b] text-white py-3 px-4 rounded-xl border border-slate-700/50 focus:border-orange-500 outline-none text-sm placeholder-slate-600 transition-colors"
                      />
                    </div>
                  </div>
                )}
              </section>
              
              {/* Custom Prompt */}
              <section className="animate-fade-in delay-300 bg-slate-900/50 p-6 rounded-2xl border border-slate-800/50 relative" style={{ zIndex: 0 }}>
                <h2 className="text-xs font-bold text-orange-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-orange-500/20 text-orange-500 flex items-center justify-center text-[10px]">5</span>
                  Custom Instructions (Optional)
                </h2>
                <textarea
                  className="w-full bg-[#1e293b] text-white py-3 px-4 rounded-xl border border-slate-700/50 focus:border-orange-500 outline-none text-sm placeholder-slate-600 min-h-[80px] transition-colors"
                  placeholder="Add specific details, e.g. 'Add a red scarf', 'Make it rainy', 'Cyberpunk style lighting'..."
                  value={state.customPrompt}
                  onChange={(e) => updateState('customPrompt', e.target.value)}
                />
              </section>
            </div>

            {/* Right Column (Action & Result) */}
            <div className="lg:col-span-4 space-y-6 sticky top-24 z-10">
               {/* Generate Button (Desktop Sidebar) */}
              <div className="bg-[#151f32] p-6 rounded-2xl border border-slate-800 shadow-xl">
                 <button
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="w-full bg-orange-500 hover:bg-orange-400 active:bg-orange-600 text-black font-black uppercase text-lg py-5 rounded-xl shadow-xl shadow-orange-500/20 transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-[1.02] active:scale-[0.98]"
                >
                  {isGenerating ? (
                    <>
                      <i className="fa-solid fa-spinner fa-spin"></i>
                      Generating...
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-wand-magic-sparkles"></i>
                      Generate Portrait
                    </>
                  )}
                </button>
                <p className="text-center text-[10px] text-slate-500 mt-4 uppercase tracking-widest">Powered by Gemini 2.5 Flash</p>
              </div>

               {/* Error */}
               {error && (
                <div className="p-4 bg-red-500/20 border border-red-500/50 rounded-xl text-red-200 text-sm text-center animate-fade-in">
                  <i className="fa-solid fa-circle-exclamation mr-2"></i>
                  {error}
                </div>
              )}

              {/* Generated Prompt Display */}
              {generatedPrompt && (
                <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 animate-fade-in">
                  <h3 className="text-[10px] text-orange-500 font-bold uppercase tracking-widest mb-2 flex items-center gap-2">
                    <i className="fa-solid fa-terminal"></i> Final Prompt
                  </h3>
                  <div className="text-[10px] text-slate-400 font-mono break-words leading-relaxed max-h-32 overflow-y-auto pr-2 custom-scrollbar">
                    {generatedPrompt}
                  </div>
                </div>
              )}

              {/* Result Area */}
              {generatedImage ? (
                <div className="space-y-4 animate-fade-in" id="result">
                  <div className="rounded-2xl overflow-hidden border-2 border-orange-500/30 shadow-2xl relative group">
                    <img src={generatedImage} alt="Generated Portrait" className="w-full h-auto" />
                  </div>
                  <a 
                    href={generatedImage} 
                    download="nano-banana-result.png"
                    className="block w-full text-center bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-xl transition-colors shadow-lg border border-slate-700"
                  >
                    <i className="fa-solid fa-download mr-2"></i> Download Result
                  </a>
                </div>
              ) : (
                <div className="hidden lg:flex aspect-[3/4] bg-slate-900/50 rounded-2xl border-2 border-dashed border-slate-800 flex-col items-center justify-center text-slate-600">
                    <i className="fa-regular fa-image text-4xl mb-4 opacity-50"></i>
                    <p className="text-xs uppercase font-bold tracking-widest">Preview Area</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* EDIT MODE UI */
          <div className="max-w-2xl mx-auto space-y-8 animate-fade-in">
             <div className="bg-[#151f32] p-8 rounded-2xl border border-slate-800 text-center shadow-2xl relative z-10">
                <div className="w-16 h-16 bg-orange-500/20 text-orange-500 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                   <i className="fa-solid fa-wand-magic"></i>
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">AI Image Editor</h2>
                <p className="text-sm text-slate-400 mb-8 max-w-md mx-auto">Upload an existing photo and use AI commands to transform it. Change backgrounds, add items, or apply styles.</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8 text-left">
                  <div className="space-y-2">
                     <label className="text-xs font-bold text-orange-500 uppercase tracking-wider ml-1">1. Source Image</label>
                     <ImageUploader 
                      label="Upload Image" 
                      image={state.editImage} 
                      onUpload={(img) => updateState('editImage', img)} 
                    />
                  </div>
                  <div className="space-y-2 flex flex-col">
                    <label className="text-xs font-bold text-orange-500 uppercase tracking-wider ml-1">2. Instructions</label>
                    <textarea
                      className="flex-1 w-full bg-[#1e293b] text-white py-4 px-5 rounded-xl border border-slate-700/50 focus:border-orange-500 outline-none text-sm placeholder-slate-600 transition-colors resize-none"
                      placeholder="e.g. 'Turn the background into a cyberpunk city', 'Make the car red', 'Add a neon sign', 'Apply a vintage filter'..."
                      value={state.editPrompt}
                      onChange={(e) => updateState('editPrompt', e.target.value)}
                    />
                  </div>
                </div>

                <button
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="w-full bg-orange-500 hover:bg-orange-400 active:bg-orange-600 text-black font-black uppercase text-lg py-4 rounded-xl shadow-xl shadow-orange-500/20 transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-[1.02] active:scale-[0.98]"
                >
                  {isGenerating ? (
                    <>
                      <i className="fa-solid fa-spinner fa-spin"></i>
                      Processing...
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-bolt"></i>
                      Apply Changes
                    </>
                  )}
                </button>
             </div>
              
              {/* Generated Prompt in Edit Mode */}
              {generatedPrompt && (
                <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 animate-fade-in max-w-2xl mx-auto">
                  <h3 className="text-[10px] text-orange-500 font-bold uppercase tracking-widest mb-2 flex items-center gap-2">
                    <i className="fa-solid fa-terminal"></i> Final Prompt
                  </h3>
                  <div className="text-[10px] text-slate-400 font-mono break-words leading-relaxed max-h-32 overflow-y-auto pr-2 custom-scrollbar">
                    {generatedPrompt}
                  </div>
                </div>
              )}

              {/* Edit Result */}
              {generatedImage && (
                <div className="bg-[#151f32] p-4 rounded-2xl border border-slate-800 animate-fade-in shadow-2xl relative z-10">
                    <div className="flex items-center justify-center gap-2 mb-4">
                      <span className="text-orange-500 font-bold text-sm uppercase tracking-widest">Result</span>
                    </div>
                    <div className="rounded-xl overflow-hidden border border-slate-700 relative">
                      <img src={generatedImage} alt="Edited Result" className="w-full h-auto" />
                    </div>
                    <a 
                      href={generatedImage} 
                      download="nano-banana-edit.png"
                      className="mt-4 block w-full text-center bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-xl transition-colors shadow-lg"
                    >
                      <i className="fa-solid fa-download mr-2"></i> Download
                    </a>
                </div>
              )}
              
               {error && (
                <div className="p-4 bg-red-500/20 border border-red-500/50 rounded-xl text-red-200 text-sm text-center animate-fade-in">
                  <i className="fa-solid fa-circle-exclamation mr-2"></i>
                  {error}
                </div>
              )}
          </div>
        )}

      </main>
      
      <style>{`
        .animate-fade-in {
          animation: fadeIn 0.5s ease-out forwards;
        }
        .delay-100 { animation-delay: 0.1s; opacity: 0; }
        .delay-200 { animation-delay: 0.2s; opacity: 0; }
        .delay-300 { animation-delay: 0.3s; opacity: 0; }
        
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #1e293b; 
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #475569; 
          border-radius: 2px;
        }
      `}</style>
    </div>
  );
};

export default App;