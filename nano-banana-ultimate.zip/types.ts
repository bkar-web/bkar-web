
export interface AppState {
  // Generation Mode State
  referenceImages: {
    front: string | null;
    left: string | null;
    right: string | null;
  };
  subject: string;
  emotion: string;
  framing: string;
  aspectRatio: string; // New field
  skinRetouch: string;
  
  // Appearance
  hairstyle: string;
  facialHair: string;
  eyeColor: string;
  bodyType: string;
  attireCategory: 'Western' | 'Eastern';
  attire: string;
  accessories: string; // New field
  
  // Scene
  sceneMode: 'Location' | 'Vehicle';
  vehicleType: string;
  vehicleModel: string;
  vehicleContext: 'Inside' | 'Outside'; // New: Inside vs Outside
  vehiclePosition: string; // New: Specific position
  vehicleEnvironment: string;
  locationCategory: string;
  locationDetail: string;
  filter: string;
  customPrompt: string;

  // Edit Mode State
  mode: 'generate' | 'edit';
  editImage: string | null;
  editPrompt: string;
}

export type ReferenceView = 'front' | 'left' | 'right';

export interface DropdownOption {
  label: string;
  icon?: string; // FontAwesome class
  id: string;
}