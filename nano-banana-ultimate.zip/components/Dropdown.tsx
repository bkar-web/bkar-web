
import React, { useState, useRef, useEffect } from 'react';
import { DropdownOption } from '../types';

interface DropdownProps {
  label?: string;
  options: DropdownOption[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
}

const Dropdown: React.FC<DropdownProps> = ({ label, options, value, onChange, placeholder, className }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const selectedOption = options.find((opt) => opt.id === value);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    // We use z-50 for the open state. The parent section z-index logic in App.tsx 
    // handles the inter-section layering.
    <div 
      className={`flex flex-col ${className} relative ${isOpen ? 'z-50' : 'z-auto'}`} 
      ref={dropdownRef}
    >
      {label && (
        <label className="text-xs font-bold text-orange-500 uppercase tracking-wider mb-1.5 ml-1">
          {label}
        </label>
      )}
      <div className="relative">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full bg-[#1e293b] hover:bg-[#2d3b55] text-white py-3 px-4 rounded-xl flex items-center justify-between transition-colors border border-slate-700/50"
          type="button"
        >
          <div className="flex items-center gap-3 overflow-hidden">
            {selectedOption?.icon && <i className={`${selectedOption.icon} text-slate-400 w-5 text-center`} />}
            <span className={`truncate ${!selectedOption ? 'text-slate-500' : ''}`}>
              {selectedOption ? selectedOption.label : placeholder || 'Select...'}
            </span>
          </div>
          <i className={`fa-solid fa-chevron-down text-slate-500 text-sm transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
        </button>

        {isOpen && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-[#0f172a] border border-slate-700 rounded-xl shadow-2xl shadow-black/50 max-h-60 overflow-y-auto overflow-x-hidden z-50">
            {options.map((option) => (
              <button
                key={option.id}
                onClick={() => {
                  onChange(option.id);
                  setIsOpen(false);
                }}
                className={`w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-slate-800 transition-colors border-b border-slate-800/50 last:border-0 ${
                  value === option.id ? 'bg-orange-500/10 text-orange-500' : 'text-slate-300'
                }`}
                type="button"
              >
                {option.icon && (
                  <i className={`${option.icon} ${value === option.id ? 'text-orange-500' : 'text-slate-500'} w-5 text-center`} />
                )}
                <span className="truncate">{option.label}</span>
                {value === option.id && <i className="fa-solid fa-check ml-auto text-xs opacity-50"></i>}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dropdown;
