import React, { useRef } from 'react';

interface ImageUploaderProps {
  label: string;
  image: string | null;
  onUpload: (base64: string | null) => void;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ label, image, onUpload }) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onUpload(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="flex flex-col items-center">
      <div 
        className="w-full aspect-[3/4] bg-[#1e293b] rounded-xl border-2 border-dashed border-slate-700 hover:border-orange-500/50 transition-colors flex flex-col items-center justify-center relative overflow-hidden group cursor-pointer"
        onClick={() => inputRef.current?.click()}
      >
        {image ? (
          <>
            <img src={image} alt={label} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
               <i className="fa-solid fa-pen-to-square text-white text-2xl"></i>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center gap-2 p-2 text-center">
             <div className="w-12 h-12 rounded-full bg-orange-500 flex items-center justify-center mb-2 shadow-lg shadow-orange-500/20">
               <i className="fa-solid fa-camera text-white"></i>
             </div>
          </div>
        )}
         <div className="absolute bottom-4 left-4 right-4 flex justify-between pointer-events-none">
             {/* Decorative icons matching screenshot */}
         </div>
      </div>
      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-3">{label}</span>
      <input 
        type="file" 
        ref={inputRef} 
        onChange={handleFileChange} 
        accept="image/*" 
        className="hidden" 
      />
      {image && (
         <button 
           onClick={(e) => { e.stopPropagation(); onUpload(null); }}
           className="mt-1 text-xs text-red-400 hover:text-red-300"
         >
           Remove
         </button>
      )}
    </div>
  );
};

export default ImageUploader;
