import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface GeneratePayload {
  prompt: string;
  referenceImages: string[]; // Base64 strings
  aspectRatio: string;
}

export const generatePortrait = async (payload: GeneratePayload): Promise<string> => {
  const { prompt, referenceImages, aspectRatio } = payload;
  
  const parts: any[] = [];
  
  // Add reference images if any
  for (const base64Img of referenceImages) {
    if (base64Img) {
      // Extract the real mime type from the data URL
      // Example: data:image/jpeg;base64,/9j/4AA...
      const mimeMatch = base64Img.match(/^data:(.*);base64,/);
      const mimeType = mimeMatch ? mimeMatch[1] : 'image/png';
      
      // Get the raw base64 data
      const base64Data = base64Img.split(',')[1] || base64Img;
      
      parts.push({
        inlineData: {
          mimeType: mimeType,
          data: base64Data,
        }
      });
    }
  }

  // Add the text prompt
  parts.push({ text: prompt });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio as any,
        }
      }
    });

    // Check for image output
    if (response.candidates && response.candidates[0].content && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    }
    
    throw new Error("No image generated.");
  } catch (error) {
    console.error("Gemini API Error:", error);
    // Return a more user-friendly error if possible
    throw error;
  }
};